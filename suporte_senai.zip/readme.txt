Para o codigo rodar, use primeiro criar_adm.php
criar o banco de dados suporte_senai.sql
rodar salas_sql.

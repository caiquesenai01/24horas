<?php
require_once 'models/conexao.php';

session_start();

if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit();
}

$required_fields = ['id_tarefa', 'nome_professor_tarefa', 'categoria_tarefa', 'status_tarefa', 'periodo'];
foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Campo obrigatório ausente: ' . $field]);
        exit();
    }
}

$id_tarefa = intval($data['id_tarefa']);
$nome_professor_tarefa = trim($data['nome_professor_tarefa']);
$categoria_tarefa = trim($data['categoria_tarefa']);
$status_tarefa = trim($data['status_tarefa']);
$periodo = trim($data['periodo']);

$valid_categorias = ['TI', 'Manutenção', 'Suporte'];
if (!in_array($categoria_tarefa, $valid_categorias)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Categoria inválida']);
    exit();
}

$valid_status = ['aberta', 'Em Andamento', 'Concluido'];
if (!in_array($status_tarefa, $valid_status)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Status inválido']);
    exit();
}

$valid_periodos = ['Manha', 'Tarde', 'Noite'];
if (!in_array($periodo, $valid_periodos)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Período inválido']);
    exit();
}

$stmt = $conn->prepare("SELECT id_tarefa FROM tarefa WHERE id_tarefa = ?");
$stmt->bind_param("i", $id_tarefa);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Tarefa não encontrada']);
    exit();
}

$stmt = $conn->prepare("UPDATE tarefa SET
    nome_professor_tarefa = ?,
    categoria_tarefa = ?,
    status_tarefa = ?,
    periodo = ?,
    data_ultima_atualizacao_tarefa = NOW()
    WHERE id_tarefa = ?");

$stmt->bind_param("ssssi",
    $nome_professor_tarefa,
    $categoria_tarefa,
    $status_tarefa,
    $periodo,
    $id_tarefa
);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Tarefa atualizada com sucesso']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar tarefa: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>

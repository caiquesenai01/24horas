<?php
require_once 'models/conexao.php';

session_start();
 //Se não estiver logado, redireciona para login
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login_adm.php");
	echo "<script>alert('Você precisa estar logado para acessar esta página.');</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Menu do Administrador</title>
	<link rel="stylesheet" href="styles/adm.css">
</head>
<body>

	
	
<button class="botao-modo" onclick="alternarModo()">
  <span class="icone-modo">◐</span>
  <span class="texto-modo">Modo Escuro</span>
</button>

<script>
function alternarModo() {
  document.body.classList.toggle('modo-noturno');
  const icone = document.querySelector('.icone-modo');
  const texto = document.querySelector('.texto-modo');
  
  if (document.body.classList.contains('modo-noturno')) {
    icone.textContent = '◑';
    texto.textContent = 'Modo Claro';
    localStorage.setItem('modo', 'noturno');
  } else {
    icone.textContent = '◐';
    texto.textContent = 'Modo Escuro';
    localStorage.setItem('modo', 'claro');
  }
}

// Verificar preferência salva
document.addEventListener('DOMContentLoaded', function() {
  const modoSalvo = localStorage.getItem('modo');
  const icone = document.querySelector('.icone-modo');
  const texto = document.querySelector('.texto-modo');
  
  if (modoSalvo === 'noturno') {
    document.body.classList.add('modo-noturno');
    icone.textContent = '◑';
    texto.textContent = 'Modo Claro';
  }
});

function editarSolicitacao(id) {
  const row = document.querySelector(`tr[data-id="${id}"]`);
  const cells = row.querySelectorAll('td:not(:last-child)');
  const editButton = row.querySelector('.btn-editar');

  if (row.classList.contains('editing')) {
    cancelarEdicao(row);
  } else {
    row.classList.add('editing');
    const editableIndices = [1, 2, 3, 6];
    cells.forEach((cell, index) => {
      if (editableIndices.includes(index)) {
        const originalValue = cell.textContent.trim();
        cell.classList.add('editavel');

        if (index === 2) { 
          const select = document.createElement('select');
          select.innerHTML = `
            <option value="TI" ${originalValue === 'TI' ? 'selected' : ''}>TI</option>
            <option value="Manutenção" ${originalValue === 'Manutenção' ? 'selected' : ''}>Manutenção</option>
            <option value="Suporte" ${originalValue === 'Suporte' ? 'selected' : ''}>Suporte</option>
          `;
          cell.innerHTML = '';
          cell.appendChild(select);
        } else if (index === 3) { 
          const select = document.createElement('select');
          select.innerHTML = `
            <option value="aberta" ${originalValue === 'aberta' ? 'selected' : ''}>Aberta</option>
            <option value="Em Andamento" ${originalValue === 'Em Andamento' ? 'selected' : ''}>Em Andamento</option>
            <option value="Concluido" ${originalValue === 'Concluido' ? 'selected' : ''}>Concluído</option>
          `;
          cell.innerHTML = '';
          cell.appendChild(select);
        } else if (index === 6) { 
          const select = document.createElement('select');
          select.innerHTML = `
            <option value="Manha" ${originalValue === 'Manha' ? 'selected' : ''}>Manhã</option>
            <option value="Tarde" ${originalValue === 'Tarde' ? 'selected' : ''}>Tarde</option>
            <option value="Noite" ${originalValue === 'Noite' ? 'selected' : ''}>Noite</option>
          `;
          cell.innerHTML = '';
          cell.appendChild(select);
        } else {
          const input = document.createElement('input');
          input.type = 'text';
          input.value = originalValue;
          cell.innerHTML = '';
          cell.appendChild(input);
        }
      }
    });

    editButton.style.display = 'none';
    const actionsCell = row.querySelector('td:last-child');
    actionsCell.innerHTML = `
      <button class="btn-salvar" onclick="salvarEdicao(${id})">Salvar</button>
      <button class="btn-cancelar" onclick="cancelarEdicao(this.closest('tr'))">Cancelar</button>
    `;
  }
}

function salvarEdicao(id) {
  const row = document.querySelector(`tr[data-id="${id}"]`);
  const inputs = row.querySelectorAll('input, select');
  const data = {
    id_tarefa: id,
    nome_professor_tarefa: inputs[0].value,
    categoria_tarefa: inputs[1].value,
    status_tarefa: inputs[2].value,
    periodo: inputs[3].value
  };

  
  fetch('update_tarefa.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      const cells = row.querySelectorAll('td:not(:last-child)');
      cells[1].textContent = data.nome_professor_tarefa;
      cells[2].textContent = data.categoria_tarefa;
      cells[3].textContent = data.status_tarefa;
      cells[6].textContent = data.periodo;

      cancelarEdicao(row);
      alert('Solicitação atualizada com sucesso!');
    } else {
      alert('Erro ao atualizar: ' + result.message);
    }
  })
  .catch(error => {
    console.error('Erro:', error);
    alert('Erro ao atualizar a solicitação.');
  });
}

function cancelarEdicao(row) {
  row.classList.remove('editing');
  const cells = row.querySelectorAll('td');
  cells.forEach(cell => cell.classList.remove('editavel'));

  
  location.reload(); 
}
</script>
	<header>
		<img src="imagens/senai.png" alt="Logo SENAI" class="logo">
	</header>
	<div class="titulo">
		<h1>Menu do Administrador</h1>
	</div>
	<div>
		<h2>Gerenciar solicitações</h2>
		<div class="filtro">
			<form action="" method="GET">
			
				<label for="Area">Área</label>
				<select name="Area" id="Area">

					<option value="TI">TI</option>
					<option value="Manutenção">Manutenção</option>
					<option value="Suporte">Suporte</option>
				</select>
				<label for="Local">Local</label>
				<select name="Local" id="Local">

					<?php
					$sql = "SELECT id_sala, nome_sala FROM salas order by nome_sala";
					$result = $conn->query($sql);
					if ($result->num_rows > 0) {
						while($row = $result->fetch_assoc()) {
							echo '<option value="'.$row["id_sala"].'">'.$row["nome_sala"].'</option>';
						}
					}
					?>
				</select>
				<label for="periodo">Período</label>
				<select name="periodo" id="periodo">

					<option value="Manha">Manhã</option>
					<option value="Tarde">Tarde</option>
					<option value="Noite">Noite</option>
				</select>
				<label for="Status">Status</label>
				<select name="Status" id="Status">

					<option value="aberta">aberta</option>
					<option value="Em Andamento">Em Andamento</option>
					<option value="Concluido">Concluído</option>
				</select>
				<div>
					<button type="submit">Filtrar</button>
				</div>
			</form>
		</div>
		<div>
			<?php

// 1. Construir base da query
$query = "SELECT tarefa.*, salas.nome_sala 
          FROM tarefa 
          JOIN salas ON tarefa.id_sala = salas.id_sala
          WHERE 1=1";


// 2. Aplicar filtros, se existirem
if (!empty($_GET['buscaNome'])) {
    $buscaNome = $_GET['buscaNome'];
    $query .= " AND tarefa.nome_professor_tarefa LIKE '%$buscaNome%'";
}

if (!empty($_GET['buscaData'])) {
    $buscaData = $_GET['buscaData'];
    $query .= " AND DATE(tarefa.data_abertura_tarefa) = '$buscaData'";
}

if (!empty($_GET['buscaHorario'])) {
    $buscaHorario = $_GET['buscaHorario'];
    if ($buscaHorario == 'manha') {
        $query .= " AND tarefa.periodo = 'Manha'";
    } elseif ($buscaHorario == 'tarde') {
        $query .= " AND tarefa.periodo = 'Tarde'";
    } elseif ($buscaHorario == 'noite') {
        $query .= " AND tarefa.periodo = 'Noite'";
    }
}

if (!empty($_GET['Area'])) {
    $area = $_GET['Area'];
    $query .= " AND tarefa.categoria_tarefa = '$area'";
}

if (!empty($_GET['Local'])) {
    $local = $_GET['Local'];
    $query .= " AND tarefa.id_sala = '$local'";
}

if (!empty($_GET['nome_sala'])) {
    $nome_sala = $_GET['nome_sala'];
    $query .= " AND nome_sala = '$nome_sala'";
}

if (!empty($_GET['Status'])) {
    $status = $_GET['Status'];
    $query .= " AND status_tarefa = '$status'";
}
if (!empty($_GET['periodo'])) {
    $periodo = $_GET['periodo'];
    $query .= " AND periodo = '$periodo'";
}
// 3. Executar query
$result = $conn->query($query);



// 4. Mostrar resultados
$numResultados = $result->num_rows;
if ($numResultados > 0) {
    echo "<table class='tabela-solicitacoes'>";
    echo "<tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Categoria</th>
            <th>Status</th>
            <th>Sala</th>
            <th>Data</th>
			<th>Período</th>
            <th>Ações</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr data-id='".$row['id_tarefa']."'>";
        echo "<td>".$row['id_tarefa']."</td>";
        echo "<td>".$row['nome_professor_tarefa']."</td>";
        echo "<td>".$row['categoria_tarefa']."</td>";
        echo "<td>".$row['status_tarefa']."</td>";
        echo "<td>".$row['nome_sala']."</td>";
        echo "<td>".$row['data_abertura_tarefa']."</td>";
		echo "<td>".$row['periodo']."</td>";
        echo "<td><button class='btn-editar' onclick='editarSolicitacao(".$row['id_tarefa'].")'>Editar</button></td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>Nenhuma solicitação encontrada.</p>";
}

?>
		</div>
	

	<nav class="navegacao">
		<ul>
			<li><a href="home.php">Voltar para Home</a></li>
		</ul>
	</nav>
</body>
</html>


    
